import React, { useState } from "react";
import { Button, Col, Modal, Row } from "react-bootstrap";
import { Heart, HeartFill } from "react-bootstrap-icons";
import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
import Logo from '../../assets/telugu1 Logo Main-01 (1).png';
import "./NonvegPickles.css";

const NonVegPickles = () => {
  const [isFavorite, setIsFavorite] = useState(Array(12).fill(false));
  const [showModal, setShowModal] = useState(false);
  const [selectedPickle, setSelectedPickle] = useState(null);
  const [selectedWeight, setSelectedWeight] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedMaterial, setSelectedMaterial] = useState(null); 

  const incrementQuantity = () => {
    setQuantity(quantity + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const addToCart = () => {
    console.log("Added to cart:", quantity);
  };

  const buyNow = () => {
    console.log("Buy now:", quantity);
  };

  const handleFavoriteToggle = (productId) => {
    setIsFavorite((prevState) => {
      const newState = [...prevState];
      newState[productId] = !newState[productId];
      return newState;
    });
  };

  const openModal = (product) => {
    setSelectedPickle(product);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const handleWeightSelection = (size) => {
    setSelectedWeight(size);
  };
  const handleMaterialSelection = (material) => {
    setSelectedMaterial(material);
  };
  const nonVegPicklesData = [
    {
      id: 1,
      name: "BONLESS CHICKEN PICKLE",
      price: "Rs 300-5225",
      image: HomeSliderImg,
      ingredients: "Ingredient 1, Ingredient 2",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 2,
      name: "CHICKEN PICKLE",
      price: "Rs 250-4275",
      image: HomeSliderImg,
      ingredients: "Ingredient 3, Ingredient 4",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 3,
      name: "PANDEM KODI PICKLE",
      price: "Rs 750-14250",
      image: HomeSliderImg,
      ingredients: "Ingredient 5, Ingredient 6",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 4,
      name: "NATU KODI PICKLE",
      price: "Rs 350-6175",
      image: HomeSliderImg,
      ingredients: "Ingredient 7, Ingredient 8",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 5,
      name: "BONLESS MUTTON PICKLE",
      price: "Rs 500-8550",
      image: HomeSliderImg,
      ingredients: "Ingredient 9, Ingredient 10",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 6,
      name: "MUTTON PICKLE",
      price: "Rs 400-7600",
      image: HomeSliderImg,
      ingredients: "Ingredient 11, Ingredient 12",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 7,
      name: "FISH PICKLE( KORAMEENU)",
      price: "Rs 300-5225",
      image: HomeSliderImg,
      ingredients: "Ingredient 13, Ingredient 14",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 8,
      name: "NETHALU PICKLE",
      price: "Rs 250-4275",
      image: HomeSliderImg,
      ingredients: "Ingredient 15, Ingredient 16",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 9,
      name: "FISH PICKLE( APOLLO FISH)",
      price: "Rs 350-6175",
      image: HomeSliderImg,
      ingredients: "Ingredient 17, Ingredient 18",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 10,
      name: "TIGER PRAWNS PICKLE ",
      price: "Rs 350-6412.5",
      image: HomeSliderImg,
      ingredients: "Ingredient 19, Ingredient 20",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 11,
      name: "SMALL PRAWNS PICKLE",
      price: "Rs 350-6650",
      image: HomeSliderImg,
      ingredients: "Ingredient 21, Ingredient 22",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    },
    {
      id: 12,
      name: "CRAB PICKLE",
      price: "Rs 400-7600",
      image: HomeSliderImg,
      ingredients: "Ingredient 23, Ingredient 24",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grams", "500 grams", "1 kgs", "2 kg", "5 kg"]
    }
  ];
  

  return (
    <div className="container py-2">
    <div className="row g-3">
      {nonVegPicklesData.map((pickle, index) => (
        <div className="col-md-3" key={index}>
          <div className="card h-100"  onClick={() => openModal(pickle)}>
            <div className="card-img-top position-relative">
              <img
                className="img-fluid rounded-top"
                src={pickle.image}
                alt={`Product ${index + 1}`}
                onClick={() => openModal(pickle)}
              />
              <div className="img-overlay">
                <button
                  className="btn-fav border-0"
                  onClick={() => handleFavoriteToggle(pickle.id)}
                >
                  {isFavorite[pickle.id] ? (
                    <HeartFill
                      className="bi bi-heart-fill text-danger bg-none fw-bold"
                      size={28}
                    />
                  ) : (
                    <Heart
                      className="bi bi-heart text-white bg-none border-none fw-bold"
                      size={28}
                    />
                  )}
                </button>
                <div className="row d-flex justify-content-center align-items-center">
                    <div className="col-md-6 ">
                <button
                  className="btn btn-shop d-flex justify-content-center align-items-center"
                  style={{
                    backgroundColor: "black",
                    width: "140px",
                    height: "40px"
                  }}
                >
                  <span className="text mx-2">Shop Now</span>
                  <svg
                    xmlns="http:www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    fill="currentColor"
                    className="bi bi-cart3 text-white"
                    viewBox="0 0 16 16"
                  >
                    <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                  </svg>
                </button>
                </div>
                </div>

                <div className="row d-flex justify-content-center align-items-center">
                    <div className="col-md-6 ">
                <button
                  className="btn btn-view d-flex justify-content-center align-items-center"
                  style={{
                    backgroundColor: "black",
                    width: "140px",
                    height: "40px"
                  }}
                  onClick={() => openModal(pickle)}
                >
                  <span className="text mx-2">View</span>
             <svg
                          xmlns="http:www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          fill="currentColor"
                          className="bi bi-eye-fill text-white"
                          viewBox="0 0 16 16"
                        >
                          <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0" />
                          <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7" />
                        </svg>
                </button>
                </div>
                </div>
              </div>
            </div>
            <div className="card-body text-center">
              <p className="card-title ">{pickle.name}</p>
              <p className="card-text ">{pickle.price}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
    <Modal show={showModal} onHide={closeModal} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          <img src={Logo} alt="" width="px" height="70px" />
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {selectedPickle && (
          <Row style={{ display: "flex", flexDirection: "row", alignItems: "center" }}>
            <Col md={4}>
              <img src={selectedPickle.image} alt="" className="img-fluid" />
            </Col>
            <Col md={8}>
        <div>
          <h4 className="py-1">{selectedPickle.name}</h4>
          <p><span className="fw-bold">Ingredients:</span> {selectedPickle.ingredients}</p>
          <p><span className="fw-bold">Description:</span> {selectedPickle.description}</p>
          <p><span className="fw-bold">Shelf Life:</span> {selectedPickle.shelfLife}</p>
          <div style={{ display: "flex" }}>
            <p className="fw-bold" style={{ marginBottom: 0, marginTop:'8px' }}>Size:</p>
            <div className="d-flex flex-wrap align-items-center">
              {/* Sizes */}
              {selectedPickle.sizes.map((size, index) => (
                <div key={index} className="m-1">
                  <Button
                    variant={selectedWeight === size ? "primary" : "outline-secondary"}
                    onClick={() => handleWeightSelection(size)}
                    className="m-1 d-flex align-items-center justify-content-center"
                    style={{
                      height: '30px',
                      borderColor: selectedWeight === size ? 'black' : '#4e1100',
                      backgroundColor: selectedWeight === size ? '#4e1100' : 'transparent',
                      color: selectedWeight === size ? 'white' : 'inherit',
                      minWidth: '70px'
                    }}
                  >
                    {size}
                  </Button>
                </div>
              ))}
            </div>
          </div>
          {/* Material */}
          <div style={{ display: "flex", alignItems: "center", marginTop: '10px' }}>
            <p className="fw-bold" style={{ marginBottom: 0 }}>Material:</p>
            <Button
              variant={selectedMaterial === "garlic" ? "primary" : "outline-primary"}
              onClick={() => handleMaterialSelection("garlic")}
              className="m-1 d-flex align-items-center justify-content-center"
              style={{
                height: '30px',
                borderColor: selectedMaterial === "garlic" ? 'black' : '#4e1100',
                backgroundColor: selectedMaterial === "garlic" ? '#4e1100' : 'transparent',
                color: selectedMaterial === "garlic" ? 'white' : 'inherit'
              }}
            >
              Garlic
            </Button>
            <Button
              variant={selectedMaterial === "without garlic" ? "primary" : "outline-primary"}
              onClick={() => handleMaterialSelection("without garlic")}
              className="m-1 d-flex align-items-center justify-content-center"
              style={{
                height: '30px',
                borderColor: selectedMaterial === "without garlic" ? 'black' : '#4e1100',
                backgroundColor: selectedMaterial === "without garlic" ? '#4e1100' : 'transparent',
                color: selectedMaterial === "without garlic" ? 'white' : 'inherit'
              }}
            >
              Without Garlic
            </Button>
          </div>
          <p className="py-2"> <span className=" fs-5 fw-bold">{selectedPickle.price}</span></p>
          {/* Quantity buttons */}
          <div className="d-flex align-items-center ">
            <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={decrementQuantity}>
              -
            </Button>
            <span className="mx-2">{quantity}</span>
            <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={incrementQuantity}>
              +
            </Button>
          </div>
        </div>
      </Col>
          </Row>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Col md={12} className="my-3 d-flex justify-content-end">
          <Button style={{ backgroundColor: '#4e1100', border: 'none', transition: "background-color 0.3s" }} className="custom-button mx-2" onClick={addToCart}>
            Add to Cart
          </Button>
          <Button className="custom-button" onClick={buyNow}>
            Buy Now
          </Button>
        </Col>
      </Modal.Footer>
    </Modal>
  </div>
  );
};

export default NonVegPickles;
