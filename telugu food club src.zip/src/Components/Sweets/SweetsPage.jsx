// import React, { useState } from "react";
// import { Button, Col, Modal, Row } from "react-bootstrap";
// import { Heart, HeartFill } from "react-bootstrap-icons";
// import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
// import Logo from '../../assets/telugu1 Logo Main-01 (1).png';
// // import "./Sweets.css"; // Import CSS file for custom styles

// const Sweets = () => {
//     const [isFavorite, setIsFavorite] = useState(Array(16).fill(false));
//     const [showModal, setShowModal] = useState(false);
//     const [selectedProduct, setSelectedProduct] = useState(null);
//     const [selectedWeight, setSelectedWeight] = useState(null);
//     const [selectedMaterial, setSelectedMaterial] = useState(null);
//     const [quantity, setQuantity] = useState(1);
  
//     const incrementQuantity = () => {
//       setQuantity(quantity + 1);
//     };
  
//     const decrementQuantity = () => {
//       if (quantity > 1) {
//         setQuantity(quantity - 1);
//       }
//     };
  
//     const addToCart = () => {
//       // Implement functionality to add product to cart
//       console.log("Added to cart:", quantity);
//     };
  
//     const buyNow = () => {
//       // Implement functionality to proceed to checkout
//       console.log("Buy now:", quantity);
//     };
  
//     const handleFavoriteToggle = (productId) => {
//       setIsFavorite((prevState) => {
//         const newState = [...prevState];
//         newState[productId] = !newState[productId];
//         return newState;
//       });
//     };
  
//     const handleWeightSelection = (size) => {
//       setSelectedWeight(size);
//     };
  
//     const handleMaterialSelection = (material) => {
//       setSelectedMaterial(material);
//     };
  
//     // Modify this function to open the modal with the selected product
//     const openModal = (product) => {
//       setSelectedProduct(product);
//       setShowModal(true);
//     };
  
//     // Close the modal
//     const closeModal = () => {
//       setShowModal(false);
//     };


//   const sweetsData = [
//     {
//       id: 1,
//       name: "Kaju Barfi",
//       price: "Rs 200-6000",
//       image: HomeSliderImg,
//       ingredients: "Ingredient 1, Ingredient 2",
//       description: "This delectable sweet is a harmonious blend of premium cashews, expertly crafted sugar syrup, and traditional recipes that come together to create a truly irresistible dessert.",
//       shelfLife: "1 month",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     {
//       id: 2,
//       name: "Gulab Jamun",
//       price: "Rs 120-3800",
//       image: HomeSliderImg,
//       ingredients: "Ingredient 3, Ingredient 4",
//       description: "These soft, spongy balls soaked in sugar syrup are a classic Indian dessert loved by all ages. Made from premium quality ingredients and traditional recipes, they are sure to delight your taste buds.",
//       shelfLife: "2 weeks",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     // Add more sweet items as needed
//   ];
  

//   return (
//     <div className="container py-2">
//       <div className="row g-3">
//         {sweetsData.map((sweet, index) => (
//           <div className="col-md-3" key={index}>
//             <div className="card h-100"   onClick={() => openModal(sweet)}>
//               <div className="card-img-top position-relative">
//                 <img
//                   className="img-fluid rounded-top"
//                   src={sweet.image}
//                   alt={`Product ${index + 1}`}
//                   onClick={() => openModal(sweet)}
//                 />
//                 <div className="img-overlay">
//                   <div className="d-flex justify-content-start">
//                     <button
//                       className="btn-fav border-0"
//                       onClick={() => handleFavoriteToggle(sweet.id)}
//                     >
//                       {isFavorite[sweet.id] ? (
//                         <HeartFill
//                           className="bi bi-heart-fill text-danger bg-none fw-bold"
//                           size={28}
//                         />
//                       ) : (
//                         <Heart
//                           className="bi bi-heart text-white bg-none border-none fw-bold"
//                           size={28}
//                         />
//                       )}
//                     </button>
//                   </div>
//                   <div className="row d-flex justify-content-center align-items-center">
//                     <div className="col-md-6 ">
//                       <button
//                         className="btn btn-shop d-flex justify-content-center align-items-center"
//                         style={{
//                           backgroundColor: "black",
//                           width: "140px",
//                           height: "40px"
//                         }}
//                       >
//                         <span className="text mx-2">Shop Now</span>
//                         <svg
//                           xmlns="http:www.w3.org/2000/svg"
//                           width="20"
//                           height="20"
//                           fill="currentColor"
//                           className="bi bi-cart3 text-white"
//                           viewBox="0 0 16 16"
//                         >
//                           <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
//                         </svg>
//                       </button>
//                     </div>
//                   </div>
//                   <div className="row d-flex justify-content-center align-items-center mt-1">
//                     <div className="col-md-6 ">
//                       <button
//                         className="btn btn-view d-flex justify-content-center align-items-center"
//                         style={{
//                           backgroundColor: "black",
//                           width: "140px",
//                           height: "40px"
//                         }}
//                         onClick={() => openModal(sweet)}
//                       >
//                         <span className="text mx-2">View Details</span>
//                         <svg
//                           xmlns="http:www.w3.org/2000/svg"
//                           width="20"
//                           height="20"
//                           fill="currentColor"
//                           className="bi bi-eye text-white"
//                           viewBox="0 0 16 16"
//                         >
//                           <path d="M8 2a1 1 0 0 1 1 1c0 .234-.105.47-.316.684C8.53 3.895 7.769 4 7 4c-.769 0-1.53-.105-2.684-.316C4.105 3.47 4 3.234 4 3a1 1 0 0 1 1-1zm0 2a5 5 0 0 1 4.995 4.783 5.5 5.5 0 0 1-.499 2.153c-.034.075-.071.151-.11.227-.328.633-.814 1.2-1.417 1.674a7.5 7.5 0 0 1-8.936 0c-.603-.475-1.09-1.041-1.417-1.674a8.93 8.93 0 0 1-.11-.227A5.498 5.498 0 0 1 3 6a5 5 0 0 1 5-5zM1 8a7 7 0 0 1 13.914-.354l-1.295 1.295a6 6 0 1 0-9.24 0L1.356 8.616A6.978 6.978 0 0 1 1 8z" />
//                         </svg>
//                       </button>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div className="card-body">
//                 <h5 className="card-title">{sweet.name}</h5>
//                 <p className="card-text">{sweet.price}</p>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>

//       <Modal show={showModal} onHide={closeModal} size="lg">
//       <Modal.Header closeButton>
//         <Modal.Title>
//           <img src={Logo} alt="" width="px" height="70px" />
//         </Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         {selectedPickle && (
//           <Row style={{ display: "flex", flexDirection: "row", alignItems: "center" }}>
//             <Col md={4}>
//               <img src={selectedPickle.image} alt="" className="img-fluid" />
//             </Col>
//             <Col md={8}>
//         <div>
//           <h4 className="py-1">{selectedPickle.name}</h4>
//           <p><span className="fw-bold">Ingredients:</span> {selectedPickle.ingredients}</p>
//           <p><span className="fw-bold">Description:</span> {selectedPickle.description}</p>
//           <p><span className="fw-bold">Shelf Life:</span> {selectedPickle.shelfLife}</p>
//           <div style={{ display: "flex" }}>
//             <p className="fw-bold" style={{ marginBottom: 0, marginTop:'8px' }}>Size:</p>
//             <div className="d-flex flex-wrap align-items-center">
//               {/* Sizes */}
//               {selectedPickle.sizes.map((size, index) => (
//                 <div key={index} className="m-1">
//                   <Button
//                     variant={selectedWeight === size ? "primary" : "outline-secondary"}
//                     onClick={() => handleWeightSelection(size)}
//                     className="m-1 d-flex align-items-center justify-content-center"
//                     style={{
//                       height: '30px',
//                       borderColor: selectedWeight === size ? 'black' : '#4e1100',
//                       backgroundColor: selectedWeight === size ? '#4e1100' : 'transparent',
//                       color: selectedWeight === size ? 'white' : 'inherit',
//                       minWidth: '70px'
//                     }}
//                   >
//                     {size}
//                   </Button>
//                 </div>
//               ))}
//             </div>
//           </div>
//           {/* Material */}
//           <div style={{ display: "flex", alignItems: "center", marginTop: '10px' }}>
//             <p className="fw-bold" style={{ marginBottom: 0 }}>Material:</p>
//             <Button
//               variant={selectedMaterial === "garlic" ? "primary" : "outline-primary"}
//               onClick={() => handleMaterialSelection("garlic")}
//               className="m-1 d-flex align-items-center justify-content-center"
//               style={{
//                 height: '30px',
//                 borderColor: selectedMaterial === "garlic" ? 'black' : '#4e1100',
//                 backgroundColor: selectedMaterial === "garlic" ? '#4e1100' : 'transparent',
//                 color: selectedMaterial === "garlic" ? 'white' : 'inherit'
//               }}
//             >
//               Garlic
//             </Button>
//             <Button
//               variant={selectedMaterial === "without garlic" ? "primary" : "outline-primary"}
//               onClick={() => handleMaterialSelection("without garlic")}
//               className="m-1 d-flex align-items-center justify-content-center"
//               style={{
//                 height: '30px',
//                 borderColor: selectedMaterial === "without garlic" ? 'black' : '#4e1100',
//                 backgroundColor: selectedMaterial === "without garlic" ? '#4e1100' : 'transparent',
//                 color: selectedMaterial === "without garlic" ? 'white' : 'inherit'
//               }}
//             >
//               Without Garlic
//             </Button>
//           </div>
//           <p className="py-2"> <span className=" fs-5 fw-bold">{selectedPickle.price}</span></p>
//           {/* Quantity buttons */}
//           <div className="d-flex align-items-center ">
//             <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={decrementQuantity}>
//               -
//             </Button>
//             <span className="mx-2">{quantity}</span>
//             <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={incrementQuantity}>
//               +
//             </Button>
//           </div>
//         </div>
//       </Col>
//           </Row>
//         )}
//       </Modal.Body>
//       <Modal.Footer>
//         <Col md={12} className="my-3 d-flex justify-content-end">
//           <Button style={{ backgroundColor: '#4e1100', border: 'none', transition: "background-color 0.3s" }} className="custom-button mx-2" onClick={addToCart}>
//             Add to Cart
//           </Button>
//           <Button className="custom-button" onClick={buyNow}>
//             Buy Now
//           </Button>
//         </Col>
//       </Modal.Footer>
//     </Modal>
//     </div>
//   );
// };

// export default Sweets;




// // 


import React, { useState } from "react";
import { Button, Col, Modal, Row } from "react-bootstrap";
import { Heart, HeartFill } from "react-bootstrap-icons";
import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
import Logo from '../../assets/telugu1 Logo Main-01 (1).png';
import './SweetsPage.css'
const Sweets = () => {
    const [isFavorite, setIsFavorite] = useState(Array(16).fill(false));
    const [showModal, setShowModal] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [selectedWeight, setSelectedWeight] = useState(null);
    const [selectedMaterial, setSelectedMaterial] = useState(null);
    const [quantity, setQuantity] = useState(1);
  
    const incrementQuantity = () => {
      setQuantity(quantity + 1);
    };
  
    const decrementQuantity = () => {
      if (quantity > 1) {
        setQuantity(quantity - 1);
      }
    };
  
    const addToCart = () => {
      // Implement functionality to add product to cart
      console.log("Added to cart:", quantity);
    };
  
    const buyNow = () => {
      // Implement functionality to proceed to checkout
      console.log("Buy now:", quantity);
    };
  
    const handleFavoriteToggle = (productId) => {
      setIsFavorite((prevState) => {
        const newState = [...prevState];
        newState[productId] = !newState[productId];
        return newState;
      });
    };
  
    const handleWeightSelection = (size) => {
      setSelectedWeight(size);
    };
  
    const handleMaterialSelection = (material) => {
      setSelectedMaterial(material);
    };
  
    // Modify this function to open the modal with the selected product
    const openModal = (product) => {
      setSelectedProduct(product);
      setShowModal(true);
    };
  
    // Close the modal
    const closeModal = () => {
      setShowModal(false);
    };


  const sweetsData = [
    {
      id: 1,
      name: "Kaju Barfi",
      price: "Rs 200-6000",
      image: HomeSliderImg,
      ingredients: "Ingredient 1, Ingredient 2",
      description: "This delectable sweet is a harmonious blend of premium cashews, expertly crafted sugar syrup, and traditional recipes that come together to create a truly irresistible dessert.",
      shelfLife: "1 month",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 2,
      name: "Gulab Jamun",
      price: "Rs 120-3800",
      image: HomeSliderImg,
      ingredients: "Ingredient 3, Ingredient 4",
      description: "These soft, spongy balls soaked in sugar syrup are a classic Indian dessert loved by all ages. Made from premium quality ingredients and traditional recipes, they are sure to delight your taste buds.",
      shelfLife: "2 weeks",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },

    {
        id: 3,
        name: "Rasgulla",
        price: "Rs 100-3000",
        image: HomeSliderImg,
        ingredients: "Ingredient 5, Ingredient 6",
        description: "Rasgulla is a syrupy dessert popular in the Indian subcontinent and regions with South Asian diaspora. It is made from ball-shaped dumplings of chhena and semolina dough, cooked in light syrup made of sugar.",
        shelfLife: "1 week",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      },
      {
        id: 4,
        name: "Jalebi",
        price: "Rs 80-2500",
        image: HomeSliderImg,
        ingredients: "Ingredient 7, Ingredient 8",
        description: "Jalebi is a sweet popular in countries of the Indian Subcontinent, West Asia, North Africa, and East Africa. It is made by deep-frying maida flour (plain flour or all-purpose flour) batter in pretzel or circular shapes, which are then soaked in sugar syrup.",
        shelfLife: "3 days",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      },

      {
        id: 5,
        name: "Rasmalai",
        price: "Rs 150-4500",
        image: HomeSliderImg,
        ingredients: "Ingredient 9, Ingredient 10",
        description: "Rasmalai is a Bengali delicacy made from soft paneer or chhena (Indian cottage cheese) patties soaked in sweet, flavored, and thickened milk.",
        shelfLife: "5 days",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      },
      {
        id: 6,
        name: "Barfi",
        price: "Rs 120-3600",
        image: HomeSliderImg,
        ingredients: "Ingredient 11, Ingredient 12",
        description: "Barfi is a sweet confectionery from the Indian subcontinent. It is typically made from condensed milk, cooked with sugar until it solidifies. Some barfi varieties are flavored with fruits, nuts, or spices such as cardamom.",
        shelfLife: "2 weeks",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      },
      {
        id: 7,
        name: "Sandesh",
        price: "Rs 100-2800",
        image: HomeSliderImg,
        ingredients: "Ingredient 13, Ingredient 14",
        description: "Sandesh is a Bengali dessert created with milk and sugar. It is often flavored with fruit extracts or essence, such as pineapple, mango, or saffron.",
        shelfLife: "1 week",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      },
      {
        id: 8,
        name: "Pedha",
        price: "Rs 130-3900",
        image: HomeSliderImg,
        ingredients: "Ingredient 15, Ingredient 16",
        description: "Pedha is a sweet from the Indian subcontinent, usually made from khoa, which is milk reduced to the consistency of a soft dough. The traditional method of preparation involves cooking khoa with sugar until thick.",
        shelfLife: "2 weeks",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      },
      {
        id: 9,
        name: "Ladoo",
        price: "Rs 90-2700",
        image: HomeSliderImg,
        ingredients: "Ingredient 17, Ingredient 18",
        description: "Ladoo or laddu is a sphere-shaped sweet originating from the Indian subcontinent. It is made of flour, minced dough, and sugar with other ingredients that vary by recipe, like chopped nuts or dried raisins.",
        shelfLife: "2 weeks",
        sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
      }
    // Add more sweet items as needed
  ];
  

  return (
    <div className="container py-2">
      <div className="row g-3">
        {sweetsData.map((sweet, index) => (
          <div className="col-md-3" key={index}>
            <div className="card h-100"   onClick={() => openModal(sweet)}>
              <div className="card-img-top position-relative">
                <img
                  className="img-fluid rounded-top"
                  src={sweet.image}
                  alt={`Product ${index + 1}`}
                />
                <div className="img-overlay">
                  <div className="d-flex justify-content-start">
                    <button
                      className="btn-fav border-0"
                      onClick={() => handleFavoriteToggle(sweet.id)}
                    >
                      {isFavorite[sweet.id] ? (
                        <HeartFill
                          className="bi bi-heart-fill text-danger bg-none fw-bold"
                          size={28}
                        />
                      ) : (
                        <Heart
                          className="bi bi-heart text-white bg-none border-none fw-bold"
                          size={28}
                        />
                      )}
                    </button>
                  </div>
                  <div className="row d-flex justify-content-center align-items-center">
                    <div className="col-md-6 ">
                      <button
                        className="btn btn-shop d-flex justify-content-center align-items-center"
                        style={{
                          backgroundColor: "black",
                          width: "140px",
                          height: "40px"
                        }}
                      >
                        <span className="text mx-2">Shop Now</span>
                        <svg
                          xmlns="http:www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          fill="currentColor"
                          className="bi bi-cart3 text-white"
                          viewBox="0 0 16 16"
                        >
                          <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div className="row d-flex justify-content-center align-items-center mt-1">
                    <div className="col-md-6 ">
                      <button
                        className="btn btn-view d-flex justify-content-center align-items-center"
                        style={{
                          backgroundColor: "black",
                          width: "140px",
                          height: "40px"
                        }}
                        onClick={() => openModal(sweet)}
                      >
                        <span className="text mx-2">View </span>
                        <svg
                          xmlns="http:www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          fill="currentColor"
                          className="bi bi-eye-fill text-white"
                          viewBox="0 0 16 16"
                        >
                          <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0" />
                          <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="card-body text-center">
                <h5 className="card-title ">{sweet.name}</h5>
                <p className="card-text ">{sweet.price}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Modal show={showModal} onHide={closeModal} size="lg">
      <Modal.Header closeButton>
        <Modal.Title>
          <img src={Logo} alt="" width="px" height="70px" />
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {selectedProduct && (
          <Row style={{ display: "flex", flexDirection: "row", alignItems: "center" }}>
            <Col md={4}>
              <img src={selectedProduct.image} alt="" className="img-fluid" />
            </Col>
            <Col md={8}>
        <div>
          <h4 className="py-1">{selectedProduct.name}</h4>
          <p><span className="fw-bold">Ingredients:</span> {selectedProduct.ingredients}</p>
          <p><span className="fw-bold">Description:</span> {selectedProduct.description}</p>
          <p><span className="fw-bold">Shelf Life:</span> {selectedProduct.shelfLife}</p>
          <div style={{ display: "flex" }}>
            <p className="fw-bold" style={{ marginBottom: 0, marginTop:'8px' }}>Size:</p>
            <div className="d-flex flex-wrap align-items-center">
              {/* Sizes */}
              {selectedProduct.sizes.map((size, index) => (
                <div key={index} className="m-1">
                  <Button
                    variant={selectedWeight === size ? "primary" : "outline-secondary"}
                    onClick={() => handleWeightSelection(size)}
                    className="m-1 d-flex align-items-center justify-content-center"
                    style={{
                      height: '30px',
                      borderColor: selectedWeight === size ? 'black' : '#4e1100',
                      backgroundColor: selectedWeight === size ? '#4e1100' : 'transparent',
                      color: selectedWeight === size ? 'white' : 'inherit',
                      minWidth: '70px'
                    }}
                  >
                    {size}
                  </Button>
                </div>
              ))}
            </div>
          </div>
          {/* Material */}
          <div style={{ display: "flex", alignItems: "center", marginTop: '10px' }}>
            <p className="fw-bold" style={{ marginBottom: 0 }}>Material:</p>
            <Button
              variant={selectedMaterial === "garlic" ? "primary" : "outline-primary"}
              onClick={() => handleMaterialSelection("garlic")}
              className="m-1 d-flex align-items-center justify-content-center"
              style={{
                height: '30px',
                borderColor: selectedMaterial === "garlic" ? 'black' : '#4e1100',
                backgroundColor: selectedMaterial === "garlic" ? '#4e1100' : 'transparent',
                color: selectedMaterial === "garlic" ? 'white' : 'inherit'
              }}
            >
              Garlic
            </Button>
            <Button
              variant={selectedMaterial === "without garlic" ? "primary" : "outline-primary"}
              onClick={() => handleMaterialSelection("without garlic")}
              className="m-1 d-flex align-items-center justify-content-center"
              style={{
                height: '30px',
                borderColor: selectedMaterial === "without garlic" ? 'black' : '#4e1100',
                backgroundColor: selectedMaterial === "without garlic" ? '#4e1100' : 'transparent',
                color: selectedMaterial === "without garlic" ? 'white' : 'inherit'
              }}
            >
              Without Garlic
            </Button>
          </div>
          <p className="py-2"> <span className=" fs-5 fw-bold">{selectedProduct.price}</span></p>
          {/* Quantity buttons */}
          <div className="d-flex align-items-center ">
            <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={decrementQuantity}>
              -
            </Button>
            <span className="mx-2">{quantity}</span>
            <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={incrementQuantity}>
              +
            </Button>
          </div>
        </div>
      </Col>
          </Row>
        )}
      </Modal.Body>
      <Modal.Footer>
        <Col md={12} className="my-3 d-flex justify-content-end">
          <Button style={{ backgroundColor: '#4e1100', border: 'none', transition: "background-color 0.3s" }} className="custom-button mx-2" onClick={addToCart}>
            Add to Cart
          </Button>
          <Button className="custom-button" onClick={buyNow}>
            Buy Now
          </Button>
        </Col>
      </Modal.Footer>
    </Modal>
    </div>
  );
};

export default Sweets;
