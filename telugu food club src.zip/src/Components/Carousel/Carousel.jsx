



import React, { useRef, useState } from "react";
import Slider from "react-slick";
import { Heart, HeartFill } from "react-bootstrap-icons";
import { Modal, Button, Row, Col } from "react-bootstrap";
import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
import "./Carousel.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Logo from '../../assets/telugu1 Logo Main-01 (1).png';

function SampleNextArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{ ...style, display: "block", background: "gray" }}
      onClick={onClick}
    />
  );
}

function SamplePrevArrow(props) {
  const { className, style, onClick } = props;
  return (
    <div
      className={className}
      style={{
        ...style,
        display: "block",
        text: "black",
        backgroundColor: "gray",
        margin: "2px"
      }}
      onClick={onClick}
    />
  );
}

const ProductCarousel = () => {
  const [index, setIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(Array(6).fill(false));
  const [showModal, setShowModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedWeight, setSelectedWeight] = useState(null);
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const sliderRef = useRef(null);
  const [autoplayPaused, setAutoplayPaused] = useState(false);
  const [quantity, setQuantity] = useState(1);

  const incrementQuantity = () => {
    setQuantity(quantity + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const addToCart = () => {
    // Implement functionality to add product to cart
    console.log("Added to cart:", quantity);
  };

  const buyNow = () => {
    // Implement functionality to proceed to checkout
    console.log("Buy now:", quantity);
  };

 

  const handleWeightSelection = (weight) => {
    setSelectedWeight(weight);
  };

  const handleMaterialSelection = (material) => {
    setSelectedMaterial(material);
  };

  const settings = {
  
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    pauseOnHover: false,
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  const handleFavoriteToggle = (productId) => {
    setIsFavorite((prevState) => {
      const newState = [...prevState];
      newState[productId] = !newState[productId];
      return newState;
    });
  };

  const openModal = (product) => {
    setSelectedProduct(product);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const handleMouseEnter = () => {
    if (sliderRef.current) {
      sliderRef.current.slickPause();
      setAutoplayPaused(true);
    }
  };

  const handleMouseLeave = () => {
    if (sliderRef.current) {
      sliderRef.current.slickPlay();
      setAutoplayPaused(false);
    }
  };

  const renderImages = () => {
    const visibleProducts = [
      {
        id: 1,
        name: "Product 1",
        price: "Rs 100-1000",
        image: HomeSliderImg,
        ingredients: "Ingredient 1, Ingredient 2",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
        shelfLife: "6 months",
        sizes: ["250g", "500g", "1kg", "5kg", ]
      },
      {
        id: 2,
        name: "Product 2",
        price: "Rs 200-1500",
        image: HomeSliderImg,
        ingredients: "Ingredient 3, Ingredient 4",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
        shelfLife: "1 year",
        sizes: ["250g", "500g", "1kg"]
      },

      {
        id: 3,
        name: "Product 3",
        price: "Rs 100-1000",
        image: HomeSliderImg,
        ingredients: "Ingredient 1, Ingredient 2",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
        shelfLife: "6 months",
        sizes: ["250g", "500g", "1kg", "5kg", ]
      },
      {
        id: 4,
        name: "Product 4",
        price: "Rs 200-1500",
        image: HomeSliderImg,
        ingredients: "Ingredient 3, Ingredient 4",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
        shelfLife: "1 year",
        sizes: ["250g", "500g", "1kg"]
      },
      {
        id: 5,
        name: "Product 5",
        price: "Rs 100-1000",
        image: HomeSliderImg,
        ingredients: "Ingredient 1, Ingredient 2",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
        shelfLife: "6 months",
        sizes: ["250g", "500g", "1kg", "5kg", ]
      },
      {
        id: 6,
        name: "Product 6",
        price: "Rs 200-1500",
        image: HomeSliderImg,
        ingredients: "Ingredient 3, Ingredient 4",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
        shelfLife: "1 year",
        sizes: ["250g", "500g", "1kg"]
      }
    ];

    return (
      <div
        className="slider-container"
        style={{ backgroundColor: "white", margin: "5px" }}
      >
        <Slider
          {...settings}
          ref={sliderRef}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          {visibleProducts.map((product, idx) => (
            <div key={idx} className="text-center">
              <div className="card m-2 "  onClick={() => openModal(product)}>
                <div className="card-img-top position-relative">
                  <img
                    className="img-fluid rounded-top"
                    src={product.image}
                    alt={`Product ${idx + 1}`}
                  />
                  <div className="img-overlay">
                    <div className="d-flex justify-content-start">
                      <button
                        className="btn-fav border-0"
                        onClick={() => handleFavoriteToggle(product.id)}
                      >
                        {isFavorite[product.id] ? (
                          <HeartFill
                            className="bi bi-heart-fill text-danger bg-none fw-bold"
                            size={28}
                          />
                        ) : (
                          <Heart
                            className="bi bi-heart text-white bg-none border-none fw-bold"
                            size={28}
                          />
                        )}
                      </button>
                    </div>
                    <div className="row d-flex justify-content-center align-items-center">
                      <div className="col-md-6 ">
                        <button
                          className="btn btn-shop d-flex justify-content-center align-items-center"
                          style={{
                            backgroundColor: "black",
                            width: "140px",
                            height: "40px"
                          }}
                        >
                          <span className="text mx-2">Shop Now</span>
                          <svg
                            xmlns="http:www.w3.org/2000/svg"
                            width="20"
                            height="20"
                            fill="currentColor"
                            className="bi bi-cart3 text-white"
                            viewBox="0 0 16 16"
                          >
                            <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div className="row d-flex justify-content-center align-items-center mt-1">
                      <div className="col-md-6 ">
                        <button
                          className="btn btn-view d-flex justify-content-center align-items-center"
                          style={{
                            backgroundColor: "black",
                            width: "140px",
                            height: "40px"
                          }}
                          onClick={() => openModal(product)}
                        >
                          <span className="text mx-2">view</span>
                          <svg
                            xmlns="http:www.w3.org/2000/svg"
                            width="20"
                            height="20"
                            fill="currentColor"
                            className="bi bi-eye-fill text-white"
                            viewBox="0 0 16 16"
                          >
                            <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0" />
                            <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card-body">
                  <h5 className="card-title">{product.name}</h5>
                  <p className="card-text">{product.price}</p>
                </div>
              </div>
            </div>
          ))}
        </Slider>
      </div>
    );
  };
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-12 py-2">{renderImages()}</div>
      </div>
      {/* <Modal show={showModal} onHide={closeModal} style={{}}>
        <Modal.Header closeButton>
          <Modal.Title>
            {selectedProduct && selectedProduct.name}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedProduct && (
            <div>
              <img
                src={selectedProduct.image}
                alt=""
                className="img-fluid"
              />
              <p>Price: {selectedProduct.price}</p>
              <p>Ingredients: {selectedProduct.ingredients}</p>
              <p>Shelf Life: {selectedProduct.shelfLife}</p>
              <Row style={{display:'flex',  alignItems:'center'}}>
                <Col md={2} >
                  <p className="fw-bold fs-6">Size:</p>
                </Col>
                <Col md={10}>
                <div className="d-flex flex-wrap">
            {selectedProduct.sizes.map((size, index) => (
              <div key={index} className="m-1">
                <Button variant="outline-secondary" size="small" onClick={() => setSelectedWeight(size)}>
                  {size}
                </Button>
              </div>
            ))}
          </div>
                </Col>
              </Row>
             
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeModal}>
            Close
          </Button>
        
        </Modal.Footer>
      </Modal> */}

<Modal show={showModal} onHide={closeModal} size="lg">
  <Modal.Header closeButton>
    <Modal.Title>
     <img src={Logo} alt="" width="px" height='70px'/>
    </Modal.Title>
  </Modal.Header>
  <Modal.Body>
    {selectedProduct && (
      <Row style={{display:'flex', flexDirection:'row', alignItems:'center'}}>
        <Col md={4}>
          <img src={selectedProduct.image} alt="" className="img-fluid" />
        </Col>
        <Col md={8}>
          <div>
            <h4 className="py-1"> {selectedProduct && selectedProduct.name}</h4>
            <p><span className="fw-bold">Ingredients :</span> {selectedProduct.ingredients}</p>
            <p><span className="fw-bold">Description :</span> {selectedProduct.description}</p>
            <p><span className="fw-bold">Shelf Life :</span> {selectedProduct.shelfLife}</p>
            <div style={{display:'flex', alignItems:'center'}}>
            <p className="fw-bold" style={{marginBottom: 0}}>Size:</p>
  <div className="d-flex flex-wrap align-items-center">
    {selectedProduct.sizes.map((size, index) => (
      <div key={index} className="m-1">
        <Button
          variant={selectedWeight === size ? "primary" : "outline-secondary"}
          onClick={() => handleWeightSelection(size)}
          className="m-1 d-flex align-items-center justify-content-center"
          style={{
            height: '30px',
            borderColor: selectedWeight === size ? 'black' : '#4e1100',
            backgroundColor: selectedWeight === size ? '#4e1100' : 'transparent',
            color: selectedWeight === size ? 'white' : 'inherit',
            minWidth: '70px'
          }}
        >
          {size}
        </Button>
      </div>
    ))}
  </div>
            </div>
            <div style={{display:'flex', alignItems:'center', marginTop: '10px'}}>
              <p className="fw-bold" style={{marginBottom: 0}}>Material:</p>
              <Button
  variant={selectedMaterial === "garlic" ? "primary" : "outline-primary"}
  onClick={() => handleMaterialSelection("garlic")}
  className="m-1 d-flex align-items-center justify-content-center"
  style={{
    height: '30px',
    borderColor: selectedMaterial === "garlic" ? 'black' : '#4e1100',
    backgroundColor: selectedMaterial === "garlic" ? '#4e1100' : 'transparent',
    color: selectedMaterial === "garlic" ? 'white' : 'inherit'
  }}
>
  Garlic
</Button>
<Button
  variant={selectedMaterial === "without garlic" ? "primary" : "outline-primary"}
  onClick={() => handleMaterialSelection("without garlic")}
  className="m-1 d-flex align-items-center justify-content-center"
  style={{
    height: '30px',
    borderColor: selectedMaterial === "without garlic" ? 'black' : '#4e1100',
    backgroundColor: selectedMaterial === "without garlic" ? '#4e1100' : 'transparent',
    color: selectedMaterial === "without garlic" ? 'white' : 'inherit'
  }}
>
  Without Garlic
</Button>
            </div>
            <p className="py-2">  <span className=" fs-5 fw-bold"> {selectedProduct.price}</span></p>
          

            <div className="d-flex  align-items-center ">
        {/* Quantity buttons */}
<div className="border rounded-3 px-2 py-1 d-flex">
        <Button variant="outline-secondary" style={{height:'25px' }} className="d-flex  align-items-center juustify-content-center fw-bold " onClick={decrementQuantity}>
          -
        </Button>
        <span className="mx-2">{quantity}</span>
        <Button variant="outline-secondary" style={{height:'25px' }} className="d-flex  align-items-center juustify-content-center fw-bold " onClick={incrementQuantity}>
          +
        </Button>
        </div>
      </div>
          </div>
        </Col>
      </Row>
    )}
  </Modal.Body>
  <Modal.Footer>
  <Col md={12} className="my-3 d-flex justify-content-end">
        {/* Add to Cart and Buy Now buttons */}
        <Button style={{backgroundColor:'#4e1100', border:'none',transition: "background-color 0.3s"}} className="custom-button mx-2" onClick={addToCart}>
          Add to Cart
        </Button>
        <Button  className="custom-button"  onClick={buyNow}>
          Buy Now
        </Button>
      </Col>
    {/* Add other buttons or actions here */}
  </Modal.Footer>
</Modal>

    </div>
  );
};

export default ProductCarousel;
