import React, { useEffect, useState } from "react";
import { Button, Col, Modal, Row } from "react-bootstrap";
import { Heart, HeartFill } from "react-bootstrap-icons";
import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
import Logo from '../../assets/telugu1 Logo Main-01 (1).png';
import "./VegPickles.css"; // Import CSS file for custom styles

const VegPickles = () => {
    const [isFavorite, setIsFavorite] = useState(Array(16).fill(false));
    const [showModal, setShowModal] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [selectedWeight, setSelectedWeight] = useState(null);
    const [selectedMaterial, setSelectedMaterial] = useState(null);
    const [quantity, setQuantity] = useState(1);
  const [price, setPrice] = useState(0);
  

  useEffect(() => {
    if (selectedProduct && selectedWeight) {
      setPrice(getPrice(selectedProduct.name, selectedWeight));
    }
  }, [selectedWeight, selectedProduct]);

  const getPrice = (productName, selectedWeight) => {
    const product = vegPicklesData.find(pickle => pickle.name === productName);
    if (product) {
      switch (selectedWeight) {
        case "250 grms":
          return product.price[0];
        case "500 grms":
          return product.price[1];
        case "1 kg":
          return product.price[2];
        case "2 kg":
          return product.price[3];
        case "5 kg":
          return product.price[4];
        case "10 kg":
          return product.price[5];
        default:
          return 0;
      }
    } else {
      return 0;
    }
  };


    useEffect(() => {
      if (selectedProduct) {
        // Initialize selectedWeight and price based on the first size option
        const initialSize = selectedProduct.sizes[0];
        setSelectedWeight(initialSize);
        setPrice(getPrice(selectedProduct.price, initialSize));
      }
    }, [selectedProduct]);
  
  

    const incrementQuantity = () => {
      setQuantity(quantity + 1);
    };
  
    const decrementQuantity = () => {
      if (quantity > 1) {
        setQuantity(quantity - 1);
      }
    };
  
    const addToCart = () => {
      // Implement functionality to add product to cart
      console.log("Added to cart:", quantity);
    };
  
    const buyNow = () => {
      // Implement functionality to proceed to checkout
      console.log("Buy now:", quantity);
    };
  
    const handleFavoriteToggle = (productId) => {
      setIsFavorite((prevState) => {
        const newState = [...prevState];
        newState[productId] = !newState[productId];
        return newState;
      });
    };
  
    const handleWeightSelection = (size) => {
      setSelectedWeight(size);
    };
  
    const handleMaterialSelection = (material) => {
      setSelectedMaterial(material);
    };
  
    // Modify this function to open the modal with the selected product
    const openModal = (product) => {
      setSelectedProduct(product);
      setShowModal(true);
    };
  
    // Close the modal
    const closeModal = () => {
      setShowModal(false);
    };


  const vegPicklesData = [
    {
      id: 1,
      name: "ANDHRA AVAKAYA (MANGO PICKLE)",
      price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 1, Ingredient 2",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 2,
      name: "TOMATO PICKLE",
      price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 3, Ingredient 4",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "1 year",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 3,
      name: "GONGURA PICKLE",
      price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 5, Ingredient 6",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 4,
      name: "ALLAM PICKLE",
      price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 7, Ingredient 8",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "1 year",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 5,
      price: [140, 260, 480, 960, 2280, 4560],
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 9, Ingredient 10",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 6,
      name: "BELLAM AVAKAYA",
      price: "Rs 160-5510",
      image: HomeSliderImg,
      ingredients: "Ingredient 11, Ingredient 12",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "1 year",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 7,
      name: "PANDU MIRAPAKAYA AVAKAYA",
      price: "Rs 160-5510",
      image: HomeSliderImg,
      ingredients: "Ingredient 13, Ingredient 14",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 8,
      name: "CAULIFOWER AVAKAYA",
      price: "Rs 120-3800",
      image: HomeSliderImg,
      ingredients: "Ingredient 15, Ingredient 16",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "1 year",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 9,
      name: "GARLIC AVAKAYA",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 17, Ingredient 18",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 10,
      name: "NIMAKAYA AVAKAYA",
    price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 19, Ingredient 20",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 11,
      name: "CHINTAKAYA PANDU MITAPAKAYA AVAKAYA",
      price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 21, Ingredient 22",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 12,
      name: "MANGO SLICE PICKLE",
      price: [140, 260, 480, 960, 2280, 4560],
      image: HomeSliderImg,
      ingredients: "Ingredient 23, Ingredient 24",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "1 year",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 13,
      name: "GONGURA PANDU MITAPAKAYA AVAKAYA",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 25, Ingredient 26",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 14,
      name: "KAKARAKAYA PICKLE",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 27, Ingredient 28",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 15,
      name: "MANGO THOKU PICKLE",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 29, Ingredient 30",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 16,
      name: "USIRIKAYA THOKU PICKLE",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 31, Ingredient 32",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 17,
      name: "MUNAKAYA AVAKAYA",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 33, Ingredient 34",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 18,
      name: "MIXED VEG PICKLE",
      price: "Rs 180-6270",
      image: HomeSliderImg,
      ingredients: "Ingredient 35, Ingredient 36",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 19,
      name: "DONDAKAYA PICKLE",
      price: "Rs 140-4560",
      image: HomeSliderImg,
      ingredients: "Ingredient 37, Ingredient 38",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    },
    {
      id: 20,
      name: "CARROT PICKLE",
      price: "Rs 140-4560",
      image: HomeSliderImg,
      ingredients: "Ingredient 39, Ingredient 40",
      description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
      shelfLife: "6 months",
      sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
    }
  ];
  

  return (
    <div className="container py-2">
      <div className="row g-3">
        {vegPicklesData.map((pickle, index) => (
          <div className="col-md-3" key={index}>
            <div className="card h-100"   >
              <div className="card-img-top position-relative">
                <img
                  className="img-fluid rounded-top"
                  src={pickle.image}
                  alt={`Product ${index + 1}`}
                  onClick={() => openModal(pickle)}
                />
                <div className="img-overlay">
                  <div className="d-flex justify-content-start">
                    <button
                      className="btn-fav border-0"
                      onClick={() => handleFavoriteToggle(pickle.id)}
                    >
                      {isFavorite[pickle.id] ? (
                        <HeartFill
                          className="bi bi-heart-fill text-danger bg-none fw-bold"
                          size={28}
                        />
                      ) : (
                        <Heart
                          className="bi bi-heart text-white bg-none border-none fw-bold"
                          size={28}
                        />
                      )}
                    </button>
                  </div>
                  <div className="row d-flex justify-content-center align-items-center">
                    <div className="col-md-6 ">
                      <button
                        className="btn btn-shop d-flex justify-content-center align-items-center"
                        style={{
                          backgroundColor: "black",
                          width: "140px",
                          height: "40px"
                        }}
                      >
                        <span className="text mx-2">Shop Now</span>
                        <svg
                          xmlns="http:www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          fill="currentColor"
                          className="bi bi-cart3 text-white"
                          viewBox="0 0 16 16"
                        >
                          <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div className="row d-flex justify-content-center align-items-center mt-1">
                    <div className="col-md-6 ">
                      <button
                        className="btn btn-view d-flex justify-content-center align-items-center"
                        style={{
                          backgroundColor: "black",
                          width: "140px",
                          height: "40px"
                        }}
                        onClick={() => openModal(pickle)} // Ensure openModal is called with the correct argument
                      >
                        <span className="text mx-2">View</span>
                        <svg
                          xmlns="http:www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          fill="currentColor"
                          className="bi bi-eye-fill text-white"
                          viewBox="0 0 16 16"
                        >
                          <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0" />
                          <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="card-body text-center" onClick={() => openModal(pickle)}>
                <p className="card-title  " >{pickle.name}</p>
                <p className="card-text ">{pickle.price}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
  <Modal show={showModal} onHide={closeModal} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            <img src={Logo} alt="" width="px" height="70px" />
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {/* Product details */}
          {selectedProduct && (
            <Row style={{ display: "flex", flexDirection: "row", alignItems: "center" }}>
              <Col md={4}>
                <img src={selectedProduct.image} alt="" className="img-fluid" />
              </Col>
              <Col md={8}>
                <div>
                  <h4 className="py-1">{selectedProduct.name}</h4>
                  <p><span className="fw-bold">Ingredients:</span> {selectedProduct.ingredients}</p>
                  <p><span className="fw-bold">Description:</span> {selectedProduct.description}</p>
                  <p><span className="fw-bold">Shelf Life:</span> {selectedProduct.shelfLife}</p>
                  <div style={{ display: "flex" }}>
                    <p className="fw-bold" style={{ marginBottom: 0,marginTop:'8px' }}>Quantity:</p>
                    <div className="d-flex flex-wrap align-items-center">
                      {/* Sizes */}
                      {selectedProduct.sizes.map((size, index) => (
                        <div key={index} className="m-1">
                          <Button
                            variant={selectedWeight === size ? "primary" : "outline-secondary"}
                            onClick={() => handleWeightSelection(size)}
                            className="m-1 d-flex align-items-center justify-content-center"
                            style={{
                              height: '30px',
                              borderColor: selectedWeight === size ? 'black' : '#4e1100',
                              backgroundColor: selectedWeight === size ? '#4e1100' : 'transparent',
                              color: selectedWeight === size ? 'white' : 'inherit',
                              minWidth: '70px'
                            }}
                          >
                            {size}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                  {/* Material */}
                  <div style={{ display: "flex", alignItems: "center", marginTop: '10px' }}>
                    <p className="fw-bold" style={{ marginBottom: 0 }}>Material:</p>
                    <Button
                      variant={selectedMaterial === "garlic" ? "primary" : "outline-primary"}
                      onClick={() => handleMaterialSelection("garlic")}
                      className="m-1 d-flex align-items-center justify-content-center"
                      style={{
                        height: '30px',
                        borderColor: selectedMaterial === "garlic" ? 'black' : '#4e1100',
                        backgroundColor: selectedMaterial === "garlic" ? '#4e1100' : 'transparent',
                        color: selectedMaterial === "garlic" ? 'white' : 'inherit'
                      }}
                    >
                      Garlic
                    </Button>
                    <Button
                      variant={selectedMaterial === "without garlic" ? "primary" : "outline-primary"}
                      onClick={() => handleMaterialSelection("without garlic")}
                      className="m-1 d-flex align-items-center justify-content-center"
                      style={{
                        height: '30px',
                        borderColor: selectedMaterial === "without garlic" ? 'black' : '#4e1100',
                        backgroundColor: selectedMaterial === "without garlic" ? '#4e1100' : 'transparent',
                        color: selectedMaterial === "without garlic" ? 'white' : 'inherit'
                      }}
                    >
                      Without Garlic
                    </Button>
                  </div>
                
                  {/* Quantity buttons */}
                  <div className="d-flex align-items-center ">
                    <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={decrementQuantity}>
                      -
                    </Button>
                    <span className="mx-2">{quantity}</span>
                    <Button variant="outline-secondary" style={{ height: '25px' }} className="d-flex align-items-center justify-content-center fw-bold " onClick={incrementQuantity}>
                      +
                    </Button>
                  </div>
                  <div className="mt-3">
                <h5 className="fw-bold">Price:</h5>
                <p>{price}</p>
              </div>
                </div>
              </Col>
            </Row>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Col md={12} className="my-3 d-flex justify-content-end">
            {/* Add to Cart and Buy Now buttons */}
            <Button style={{ backgroundColor: '#4e1100', border: 'none', transition: "background-color 0.3s" }} className="custom-button mx-2" onClick={addToCart}>
              Add to Cart
            </Button>
            <Button className="custom-button" onClick={buyNow}>
              Buy Now
            </Button>
          </Col>
          {/* Add other buttons or actions here */}
        </Modal.Footer>
      </Modal>

    </div>
  );
};

export default VegPickles;



// import React, { useEffect, useState } from "react";
// import { Button, Col, Modal, Row } from "react-bootstrap";
// import { Heart, HeartFill } from "react-bootstrap-icons";
// import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
// import Logo from '../../assets/telugu1 Logo Main-01 (1).png';
// import "./VegPickles.css"; // Import CSS file for custom styles

// const VegPickles = () => {
//   const [isFavorite, setIsFavorite] = useState(Array(16).fill(false));
//   const [showModal, setShowModal] = useState(false);
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const [selectedWeight, setSelectedWeight] = useState(null);
//   const [selectedMaterial, setSelectedMaterial] = useState(null);
//   const [quantity, setQuantity] = useState(1);
//   const [price, setPrice] = useState(0);

//   useEffect(() => {
//     if (selectedProduct && selectedWeight) {
//       setPrice(getPrice(selectedProduct.name, selectedWeight));
//     }
//   }, [selectedWeight, selectedProduct]);

//   const getPrice = (productName, selectedWeight) => {
//     const product = vegPicklesData.find(pickle => pickle.name === productName);
//     if (product) {
//       switch (selectedWeight) {
//         case "250 grms":
//           return product.price[0];
//         case "500 grms":
//           return product.price[1];
//         case "1 kg":
//           return product.price[2];
//         case "2 kg":
//           return product.price[3];
//         case "5 kg":
//           return product.price[4];
//         case "10 kg":
//           return product.price[5];
//         default:
//           return 0;
//       }
//     } else {
//       return 0;
//     }
//   };

//   const incrementQuantity = () => {
//     setQuantity(quantity + 1);
//   };

//   const decrementQuantity = () => {
//     if (quantity > 1) {
//       setQuantity(quantity - 1);
//     }
//   };

//   const addToCart = () => {
//     const totalPrice = price * quantity;
//     console.log("Added to cart. Total Price:", totalPrice);
//   };

//   const buyNow = () => {
//     const totalPrice = price * quantity;
//     console.log("Buy now. Total Price:", totalPrice);
//   };

//   const handleFavoriteToggle = (productId) => {
//     setIsFavorite((prevState) => {
//       const newState = [...prevState];
//       newState[productId] = !newState[productId];
//       return newState;
//     });
//   };

//   const handleWeightSelection = (size) => {
//     setSelectedWeight(size);
//   };

//   const handleMaterialSelection = (material) => {
//     setSelectedMaterial(material);
//   };

//   const openModal = (product) => {
//     setSelectedProduct(product);
//     setShowModal(true);
//   };

//   const closeModal = () => {
//     setShowModal(false);
//   };

//   const vegPicklesData = [
//     {
//       id: 1,
//       name: "ANDHRA AVAKAYA( MANGO PICKLE)",
//       price: [140, 260, 480, 960, 2280, 4560],
//       image: HomeSliderImg,
//       ingredients: "Ingredient 1, Ingredient 2",
//       description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
//       shelfLife: "6 months",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     {
//       id: 2,
//       name: "TOMATO PICKLE",
//       price: "Rs 120-3800",
//       image: HomeSliderImg,
//       ingredients: "Ingredient 3, Ingredient 4",
//       description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
//       shelfLife: "1 year",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     {
//       id: 3,
//       name: "GONGURA PICKLE",
//       price: "Rs 120-3800",
//       image: HomeSliderImg,
//       ingredients: "Ingredient 5, Ingredient 6",
//       description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
//       shelfLife: "6 months",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     {
//       id: 4,
//       name: "ALLAM PICKLE",
//       price: "Rs 180-6270",
//       image: HomeSliderImg,
//       ingredients: "Ingredient 7, Ingredient 8",
//       description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
//       shelfLife: "1 year",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     {
//       id: 5,
//       name: "USIRIKAYA AVAKAYA",
//       price: "Rs 180-6270",
//       image: HomeSliderImg,
//       ingredients: "Ingredient 9, Ingredient 10",
//       description: "This delectable pickle is a harmonious blend of handpicked seasonal vegetables, expertly crafted spices, and traditional recipes that come together to create a truly irresistible condiment.",
//       shelfLife: "6 months",
//       sizes: ["250 grms", "500 grms", "1 kg", "2 kg", "5 kg", "10 kg"]
//     },
//     // Add other pickle data here...
//   ];

//   return (
//     <div className="container py-2">
//       <div className="row g-3">
//         {vegPicklesData.map((pickle, index) => (
//           <div className="col-md-3" key={index}>
//             <div className="card h-100">
//               <div className="card-img-top position-relative">
//                 <img
//                   className="img-fluid rounded-top"
//                   src={pickle.image}
//                   alt={`Product ${index + 1}`}
//                   onClick={() => openModal(pickle)}
//                 />
//                 <div className="img-overlay">
//                   <div className="d-flex justify-content-start">
//                     <button
//                       className="btn-fav border-0"
//                       onClick={() => handleFavoriteToggle(pickle.id)}
//                     >
//                       {isFavorite[pickle.id] ? (
//                         <HeartFill
//                           className="bi bi-heart-fill text-danger bg-none fw-bold"
//                           size={28}
//                         />
//                       ) : (
//                         <Heart
//                           className="bi bi-heart text-white bg-none border-none fw-bold"
//                           size={28}
//                         />
//                       )}
//                     </button>
//                   </div>
//                   <div className="row d-flex justify-content-center align-items-center">
//                     <div className="col-md-6">
//                       <button
//                         className="btn btn-shop d-flex justify-content-center align-items-center"
//                         style={{
//                           backgroundColor: "black",
//                           width: "140px",
//                           height: "40px"
//                         }}
//                       >
//                         <span className="text mx-2">Shop Now</span>
//                         <svg
//                           xmlns="http:www.w3.org/2000/svg"
//                           width="20"
//                           height="20"
//                           fill="currentColor"
//                           className="bi bi-cart3 text-white"
//                           viewBox="0 0 16 16"
//                         >
//                           <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l.84 4.479 9.144-.459L13.89 4zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2m7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2"></path>
//                         </svg>
//                       </button>
//                     </div>
//                     <div className="col-md-6">
//                       <button
//                         className="btn btn-fav d-flex justify-content-center align-items-center"
//                         style={{
//                           backgroundColor: "black",
//                           width: "40px",
//                           height: "40px"
//                         }}
//                         onClick={() => openModal(pickle)}
//                       >
//                         <svg
//                           xmlns="http://www.w3.org/2000/svg"
//                           width="20"
//                           height="20"
//                           fill="currentColor"
//                           className="bi bi-eye"
//                           viewBox="0 0 16 16"
//                         >
//                           <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zM2.93 8a5.053 5.053 0 0 1 8.14-4.04 5.053 5.053 0 0 1 0 8.08A5.053 5.053 0 0 1 2.93 8zM8 4a4 4 0 1 0 0 8A4 4 0 0 0 8 4z"></path>
//                           <path d="M8 5a3 3 0 1 0 0 6A3 3 0 0 0 8 5z"></path>
//                         </svg>
//                       </button>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div className="card-body">
//                 <h5 className="card-title fw-bold">{pickle.name}</h5>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//       <Modal show={showModal} onHide={closeModal}>
//         <Modal.Header closeButton>
//           <Modal.Title>{selectedProduct && selectedProduct.name}</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <Row>
//             <Col>
//               <img
//                 className="img-fluid rounded"
//                 src={selectedProduct && selectedProduct.image}
//                 alt={selectedProduct && selectedProduct.name}
//               />
//             </Col>
//             <Col>
//               <h5 className="fw-bold">Description:</h5>
//               <p>{selectedProduct && selectedProduct.description}</p>
//               <h5 className="fw-bold">Ingredients:</h5>
//               <p>{selectedProduct && selectedProduct.ingredients}</p>
//               <h5 className="fw-bold">Shelf Life:</h5>
//               <p>{selectedProduct && selectedProduct.shelfLife}</p>
//               <div>
//                 <h5 className="fw-bold">Weight:</h5>
//                 {selectedProduct &&
//                   selectedProduct.sizes.map((size, index) => (
//                     <button
//                       key={index}
//                       className={`btn btn-outline-dark mx-2 ${
//                         selectedWeight === size ? "active" : ""
//                       }`}
//                       onClick={() => handleWeightSelection(size)}
//                     >
//                       {size}
//                     </button>
//                   ))}
//               </div>
//               <div>
//                 <h5 className="fw-bold">Material:</h5>
//                 {/* Render material options here */}
//               </div>
//               <div>
//                 <h5 className="fw-bold">Quantity:</h5>
//                 <button className="btn btn-dark mx-2" onClick={decrementQuantity}>
//                   -
//                 </button>
//                 <span>{quantity}</span>
//                 <button className="btn btn-dark mx-2" onClick={incrementQuantity}>
//                   +
//                 </button>
//               </div>
//               <div className="mt-3">
//                 <h5 className="fw-bold">Price:</h5>
//                 <p>{price}</p>
//               </div>
//             </Col>
//           </Row>
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={closeModal}>
//             Close
//           </Button>
//           <Button variant="primary" onClick={addToCart}>
//             Add to Cart
//           </Button>
//           <Button variant="success" onClick={buyNow}>
//             Buy Now
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// };

// export default VegPickles;
