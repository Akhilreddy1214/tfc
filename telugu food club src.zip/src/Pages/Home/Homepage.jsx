
import React, { useState } from "react";
import {
  Container,
  Row,
  Col,
  Carousel,
  Modal,
  Button,
  Dropdown,
} from "react-bootstrap";
import FoodNavbar from "../../Components/Navbar/NavBar";
import HomeSliderImg from "../../assets/image 13HomeSliderImg.png";
import { HeartFill, Heart } from "react-bootstrap-icons";
import "./HomePage.css";
import ProductCarousel from "../../Components/Carousel/Carousel";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import VegPickles from "../../Components/Vegpickles/VegPickles";
import NonVegPickles from "../../Components/NonVeg/NonvegPickles";
import Sweets from "../../Components/Sweets/SweetsPage";
import VegCarousel from "../../Components/VegPicklesCarousel/VegCarousel";
import NonVegCarousel from "../../Components/NonVegCarousel/NonVegCarousel";
import Footer from "../../Components/Footer/Footer";

const HomePage = () => {


    const [activeTab, setActiveTab] = useState("tab1");
  
    const handleTabChange = (tab) => {
      setActiveTab(tab);
    };
  return (
    <>
      <FoodNavbar />
      <Container>
        <div className="demo">
          <div className="">
            <div className="row d-flex align-items-center">
              <div className="col-lg-4">
                <div className="content">
                  <h2>Content</h2>
                  <p>
                    This is your content column. You can add any text or
                    components here.
                  </p>
                </div>
              </div>
              <div className="col-lg-8">
                <Carousel>
                  <Carousel.Item interval={6000}>
                    <img src={HomeSliderImg} alt="" className="img-fluid" />
                    <Carousel.Caption>
                      <button
                        className="btn text-white"
                        style={{ backgroundColor: "#4e1100" }}
                      >
                        Shop Now
                      </button>
                    </Carousel.Caption>
                  </Carousel.Item>
                  <Carousel.Item interval={500}>
                    <img src={HomeSliderImg} alt="" className="img-fluid" />
                    <Carousel.Caption>
                      <button
                        className="btn text-white"
                        style={{ backgroundColor: "#4e1100" }}
                      >
                        Shop Now
                      </button>
                    </Carousel.Caption>
                  </Carousel.Item>
                  <Carousel.Item>
                    <img src={HomeSliderImg} alt="" className="img-fluid" />
                    <Carousel.Caption>
                      <button
                        className="btn text-white"
                        style={{ backgroundColor: "#4e1100" }}
                      >
                        Shop Now
                      </button>
                    </Carousel.Caption>
                  </Carousel.Item>
                </Carousel>
              </div>
            </div>
       
          </div>
        </div>
      </Container>

     
    <div className="container-fluid" style={{backgroundColor:'rgba(255, 175, 0, 0.1)'}}>
<div className="py-4" >
<ProductCarousel />
</div>


    </div>
    <div className="container" >
      <h4 className="text-center py-2">Featured Products</h4>
      <div className="row">
        <div className="col">
          <ul className="nav nav-tabs">
            <li className="nav-item mx-2">
              <button
                className={`nav-link ${activeTab === "tab1" ? "active" : ""}`}
                
                onClick={() => handleTabChange("tab1")}
              >
        All
              </button>
            </li>
            <li className="nav-item mx-2">
              <button
                className={`nav-link ${activeTab === "tab2" ? "active" : ""}`}
                onClick={() => handleTabChange("tab2")}
              >
              Veg-Pickles
              </button>
            </li>
            <li className="nav-item mx-2">
              <button
                className={`nav-link ${activeTab === "tab3" ? "active" : ""}`}
                onClick={() => handleTabChange("tab3")}
              >
               Non-Veg Pickles
              </button>
            </li>
            <li className="nav-item mx-2">
              <button
                className={`nav-link ${activeTab === "tab4" ? "active" : ""}`}

                onClick={() => handleTabChange("tab4")}
              >
             Sweets
              </button>
            </li>
            <li className="nav-item mx-2">
              <button
                className={`nav-link ${activeTab === "tab5" ? "active" : ""}`}
                onClick={() => handleTabChange("tab5")}
              >
              Other Products
              </button>
            </li>
          </ul>
        </div>
      </div>
      <div className="row">
        <div className="col">
          <div className="tab-content">
            <div
              className={`tab-pane fade ${
                activeTab === "tab1" ? "show active" : ""
              }`}
              id="tab1"
            >
            <VegCarousel />
            <NonVegCarousel />
            </div>
            <div
              className={`tab-pane fade ${
                activeTab === "tab2" ? "show active" : ""
              }`}
              id="tab2"
            >
              
           <VegPickles />
            </div>
            <div
              className={`tab-pane fade ${
                activeTab === "tab3" ? "show active" : ""
              }`}
              id="tab3"
            >
             <NonVegPickles />
            </div>
            <div
              className={`tab-pane fade ${
                activeTab === "tab4" ? "show active" : ""
              }`}
              id="tab4"
            >
           <Sweets />
            </div>
            <div
              className={`tab-pane fade ${
                activeTab === "tab5" ? "show active" : ""
              }`}
              id="tab5"
            >
              <h2>Tab 5 Content</h2>
              {/* Add your content for Tab 5 here */}
            </div>
          </div>
        </div>
      </div>
    </div>
     <Footer />
    </>
  );
};

export default HomePage;
